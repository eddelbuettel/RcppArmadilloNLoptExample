#' @useDynLib nloptCpp
#' @importFrom Rcpp sourceCpp
#' @import nloptr
#' @import RcppArmadillo
NULL
